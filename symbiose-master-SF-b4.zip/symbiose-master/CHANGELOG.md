2013-05-08 Simon Ser contact@emersion.fr



For a full changelog, run `git log`.
