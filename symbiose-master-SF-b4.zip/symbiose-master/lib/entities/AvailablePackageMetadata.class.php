<?php
namespace lib\entities;

interface AvailablePackageMetadata {}