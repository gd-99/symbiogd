<?php
namespace lib\manager;

abstract class ConfigManager extends \lib\Manager {}