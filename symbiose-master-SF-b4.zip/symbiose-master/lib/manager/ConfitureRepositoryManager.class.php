<?php
namespace lib\manager;

use \lib\Manager;
use \lib\Repository;

abstract class ConfitureRepositoryManager extends Manager implements Repository {}