<?php
namespace lib\manager;

abstract class FileManager extends \lib\Manager {}