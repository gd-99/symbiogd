<?php
namespace lib\manager;

abstract class LauncherManager extends \lib\Manager {}