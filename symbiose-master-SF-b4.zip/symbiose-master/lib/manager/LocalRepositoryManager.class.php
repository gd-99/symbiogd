<?php
namespace lib\manager;

use \lib\Repository;

abstract class LocalRepositoryManager extends \lib\Manager implements Repository {}