<?php
namespace lib\manager;

abstract class SharedFileManager extends \lib\Manager {}