<?php
require_once(dirname(__FILE__).'/../boot/ini.php');

$api = new lib\Api;
$api->render();