<?php
require_once(dirname(__FILE__).'/../boot/ini.php');

$api = new lib\ApiGroup;
$api->render();