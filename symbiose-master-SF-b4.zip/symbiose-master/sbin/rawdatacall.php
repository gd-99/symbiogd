<?php
require_once(dirname(__FILE__).'/../boot/ini.php');

$call = new lib\RawDataCall;
$call->render();